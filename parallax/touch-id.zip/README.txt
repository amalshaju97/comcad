A Pen created at CodePen.io. You can find this one at https://codepen.io/winkerVSbecks/pen/vGojNb.

 Made the SVG icon using Anton Kudin's guide
    https://dribbble.com/shots/1288075-how-to-create-touch-id-logo

  Animation _heavily_ inspired by
    https://dribbble.com/shots/2279809-Mad-futuristic-security-login-type-dealings

The animation is created using Web Animation API. Only works in Chrome ¯\_(ツ)_/¯

https://github.com/winkerVSbecks/touch-id